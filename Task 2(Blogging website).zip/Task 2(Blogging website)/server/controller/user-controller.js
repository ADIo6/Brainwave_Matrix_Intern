
// import User from '../model/user.js'


// export const signUpUser = async(request, response) =>{
//     try {
//         const user = request.body;
//         const newUser = new User(user);
//         await newUser.save();
//         return response.status(200).json({msg: 'Sign-Up Successfull'});
//     } catch (error) {
//         return response.status(500).json({msg: 'Error While Sign-Up'});
        
//     }
// }

import User from '../model/user.js';

export const signUpUser = async (request, response) => {
    try {
        // Destructure the user fields from the request body
        const { name, email, password } = request.body;

        // Check if all required fields are present
        if (!name || !email || !password) {
            return response.status(400).json({ msg: "All fields are required" });
        }

        // Check if a user with the provided email already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return response.status(409).json({ msg: "Email already registered" });
        }

        // Create a new user with the provided data
        const newUser = new User({
            name,
            email,
            password  // Add your password field directly (no hashing for now)
        });

        // Save the new user to the database
        await newUser.save();

        // Respond with a success message
        return response.status(201).json({ msg: 'Sign-Up Successful' });
    } catch (error) {
        console.error("Error during sign-up:", error);
        return response.status(500).json({ msg: 'Error While Sign-Up' });
    }
};
