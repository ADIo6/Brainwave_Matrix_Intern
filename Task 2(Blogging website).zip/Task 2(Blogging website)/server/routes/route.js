//routes are the end point of an API



import express from 'express';
import { signUpUser } from '../controller/user-controller.js';

const Router = express.Router();

Router.post('/signup', signUpUser);


export default Router;
