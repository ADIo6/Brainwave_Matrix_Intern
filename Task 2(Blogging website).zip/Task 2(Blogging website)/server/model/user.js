// import mongoose from "mongoose";

// const userSchema =  mongoose.Schema({
//     name: {
//         type: String,
//         required: true
//     },

//    //^^ it was written username before 
//     email:{
//         type: String,
//         required: true,
//         unique: true
//     },

//     password:{
//         type: String,
//         required: true,

//     }
// })

// const user = mongoose.model('user', userSchema);

// export default user;

//^^
import mongoose from "mongoose";

// Define the user schema
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    }
}, {
    timestamps: true // Automatically adds `createdAt` and `updatedAt` fields
});

// Create the User model
const User = mongoose.model('User', userSchema);

export default User;
