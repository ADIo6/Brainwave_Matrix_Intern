import logo from './logo.svg';
import './App.css';
// components
import Login from './component/account/Login'

function App() {
  return (
    <div style = {{marginTop: 60}}>
        <Login />
    </div>
  );
}

export default App;
